package com.kh.d_chat.server;

public class Run {

	public static void main(String[] args) {
		new ChatServer().startServer();
	}
}
